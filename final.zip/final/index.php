<?php
  header('Location: pages/main.php');
?>
<?php
  header('Location: pages/index.html');
?>

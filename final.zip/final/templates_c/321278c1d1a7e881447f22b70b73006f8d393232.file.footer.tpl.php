<?php /* Smarty version Smarty-3.1.15, created on 2014-06-03 21:01:38
         compiled from "/opt/lbaw/lbaw1342/public_html/dev/templates/common/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:334621605367bae0142f52-90482357%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '321278c1d1a7e881447f22b70b73006f8d393232' => 
    array (
      0 => '/opt/lbaw/lbaw1342/public_html/dev/templates/common/footer.tpl',
      1 => 1401825695,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '334621605367bae0142f52-90482357',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_5367bae0145d36_23562231',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5367bae0145d36_23562231')) {function content_5367bae0145d36_23562231($_smarty_tpl) {?>	<hr>
	<footer>
	  <p>
		&nbsp;&nbsp;&nbsp;&nbsp;&copy; Gestorax - Inventory Management 2014
	  </p>
	</footer>
</html><?php }} ?>

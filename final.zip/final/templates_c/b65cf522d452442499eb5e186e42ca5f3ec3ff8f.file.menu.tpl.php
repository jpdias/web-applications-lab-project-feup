<?php /* Smarty version Smarty-3.1.15, created on 2014-06-06 21:50:55
         compiled from "/opt/lbaw/lbaw1342/public_html/final/templates/common/menu.tpl" */ ?>
<?php /*%%SmartyHeaderCode:19506860765392281e0ddf15-88387815%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b65cf522d452442499eb5e186e42ca5f3ec3ff8f' => 
    array (
      0 => '/opt/lbaw/lbaw1342/public_html/final/templates/common/menu.tpl',
      1 => 1402087848,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19506860765392281e0ddf15-88387815',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_5392281e15d707_64357403',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5392281e15d707_64357403')) {function content_5392281e15d707_64357403($_smarty_tpl) {?><div class="navbar navbar-default navbar-fixed-top" role="navigation">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
        <span class="sr-only">
          Toggle navigation
        </span>
        <span class="icon-bar">
        </span>
        <span class="icon-bar">
        </span>
        <span class="icon-bar">
        </span>
      </button>
      <a class="navbar-brand" href="main.php">
        <img href="" src="../resources/logo.png" style="width:6%;hight:6%">
        Gestorax - Inventory Management
      </a>
    </div>
    <div class="navbar-collapse collapse">
    </div>
  </div>
</div><?php }} ?>

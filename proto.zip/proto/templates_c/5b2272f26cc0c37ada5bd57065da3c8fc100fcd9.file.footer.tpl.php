<?php /* Smarty version Smarty-3.1.15, created on 2014-04-07 09:24:44
         compiled from "/opt/lbaw/lbaw1342/public_html/frmk/templates/common/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1628176505534260ccf2de48-21129669%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5b2272f26cc0c37ada5bd57065da3c8fc100fcd9' => 
    array (
      0 => '/opt/lbaw/lbaw1342/public_html/frmk/templates/common/footer.tpl',
      1 => 1386927924,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1628176505534260ccf2de48-21129669',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_534260ccf2fae1_05602181',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_534260ccf2fae1_05602181')) {function content_534260ccf2fae1_05602181($_smarty_tpl) {?>  </body>
</html>
<?php }} ?>

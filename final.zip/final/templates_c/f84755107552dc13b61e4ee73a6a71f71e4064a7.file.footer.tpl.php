<?php /* Smarty version Smarty-3.1.15, created on 2014-06-06 20:47:45
         compiled from "/opt/lbaw/lbaw1342/public_html/final/templates/common/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:160088317153921ae1b34939-60892648%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f84755107552dc13b61e4ee73a6a71f71e4064a7' => 
    array (
      0 => '/opt/lbaw/lbaw1342/public_html/final/templates/common/footer.tpl',
      1 => 1401825695,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '160088317153921ae1b34939-60892648',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_53921ae1b37387_63360561',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_53921ae1b37387_63360561')) {function content_53921ae1b37387_63360561($_smarty_tpl) {?>	<hr>
	<footer>
	  <p>
		&nbsp;&nbsp;&nbsp;&nbsp;&copy; Gestorax - Inventory Management 2014
	  </p>
	</footer>
</html><?php }} ?>
